/*
1.2 (Display five messages) 
Write a program that displays "Welcome to Java" five times.

 */

/**
 * @author jacob
 *
 */
public class A1dot2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		for (int i = 0; i < 5; i++) {
			System.out.println("Welcome to Java");	
		}
		
	}

}
