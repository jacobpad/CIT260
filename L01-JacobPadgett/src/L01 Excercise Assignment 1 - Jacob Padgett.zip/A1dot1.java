/*
 * 1.1 (Display three messages) Write a program that displays 
 * "Welcome to Java", 
 * "Welcome to Computer Science", and 
 * "Programming is fun."
 * 
 */

/**
 * @author jacob
 *
 */
public class A1dot1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("Welcome to Java!");
		System.out.println("Welcome to Computer Science");
		System.out.println("Programming is fun.");
	}

}
